const addToCart = require('./modules/addToCart');
const removeFromCart = require('./modules/removeFromCart');
const listCart = require('./modules/listCart');
const calculateTotal = require('./modules/calculateTotal');

// Example usage:
addToCart('p1');
addToCart('p2');
listCart();
calculateTotal();
removeFromCart('p1');
