const fs = require('fs');
const path = require('path');
const cartPath = path.join(__dirname, '../data/cart.json');

function listCart() {
    const cart = JSON.parse(fs.readFileSync(cartPath));
    console.log('Cart items:', cart);
}

module.exports = listCart;
