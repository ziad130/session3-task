const fs = require('fs');
const path = require('path');
const cartPath = path.join(__dirname, '../data/cart.json');

function removeFromCart(productId) {
    let cart = JSON.parse(fs.readFileSync(cartPath));
    const initialLength = cart.length;
    cart = cart.filter(item => item.id !== productId);
    fs.writeFileSync(cartPath, JSON.stringify(cart, null, 2));
    console.log(initialLength === cart.length ? 'Item not found in cart.' : 'Item removed from cart.');
}

module.exports = removeFromCart;
