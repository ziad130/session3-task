const fs = require('fs');
const path = require('path');
const contactsPath = path.join(__dirname, '../data/contacts.json');

function listContacts() {
    const contacts = JSON.parse(fs.readFileSync(contactsPath));
    console.log('All contacts:', contacts);
}

module.exports = listContacts;
