const fs = require('fs');
const path = require('path');
const contactsPath = path.join(__dirname, '../data/contacts.json');

function searchContact(name) {
    const contacts = JSON.parse(fs.readFileSync(contactsPath));
    const results = contacts.filter(contact =>
        contact.name.toLowerCase().includes(name.toLowerCase())
    );
    console.log('Search results:', results);
}

module.exports = searchContact;
