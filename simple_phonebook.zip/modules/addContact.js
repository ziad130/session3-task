const fs = require('fs');
const path = require('path');
const contactsPath = path.join(__dirname, '../data/contacts.json');

function addContact(name, phone) {
    const contacts = JSON.parse(fs.readFileSync(contactsPath));
    const newContact = {
        id: Date.now().toString(),
        name,
        phone
    };
    contacts.push(newContact);
    fs.writeFileSync(contactsPath, JSON.stringify(contacts, null, 2));
    console.log('Contact added:', newContact);
}

module.exports = addContact;
