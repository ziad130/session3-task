const addContact = require('./modules/addContact');
const removeContact = require('./modules/removeContact');
const searchContact = require('./modules/searchContact');
const listContacts = require('./modules/listContacts');

// Example usage:
addContact('Alice', '123-456-7890');
addContact('Bob', '987-654-3210');
listContacts();
searchContact('alice');
removeContact('some-id-here');
